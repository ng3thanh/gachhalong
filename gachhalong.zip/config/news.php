<?php

return [
    'news' => 'News',
    'introduce' => 'Introduce',
    'document' => 'Document'
];

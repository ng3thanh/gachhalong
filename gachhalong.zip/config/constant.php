<?php

return [
    'email' => 'tandinhphat2018@gmail.com',
    'address' => 'Chợ Cháy - Chẩn Kỳ - Trung Tú - Ứng Hoà - Hà Nội',
    'phone' => '0928120298',
    'phone_format' => '092.812.0298',
];
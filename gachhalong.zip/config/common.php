<?php

return [
    'mail' => env('APP_MAIL', 'ng3thanh@gmail.com'),
];

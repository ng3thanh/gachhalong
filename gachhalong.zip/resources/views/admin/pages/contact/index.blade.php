@extends('admin.layout') @section('title', 'Danh sách phản hồi')

@section('css') 
<!-- Select2 -->
<link rel="stylesheet" href="{{ asset('admin/css/select2.min.css') }}">
@endsection 

@section('content')
<!-- Main content -->
<section class="content">
	<div class="row">

	</div>
</section>
<!-- /.content -->


@endsection 

@section('script') 
<script src="{{ asset('admin/js/select2.full.min.js') }}"></script>

@endsection

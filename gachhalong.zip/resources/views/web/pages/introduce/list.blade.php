@extends('web.layout') 
@section('title', 'Gạch Hạ Long')
@section('css')

@endsection
@section('js')

@endsection

@section('content')


@endsection 
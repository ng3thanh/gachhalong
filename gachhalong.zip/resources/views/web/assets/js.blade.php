<script type="application/x-javascript"> 
    addEventListener("load", function() { 
        setTimeout(hideURLbar, 0); 
    }, false);
    
    function hideURLbar(){ 
        window.scrollTo(0,1); 
    } 
</script>

<script type="text/javascript" src="{{ asset('js/jquery-2.1.4.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/bootstrap-3.1.1.min.js') }}"></script>

<script src="{{ asset('js/jquery.easing.min.js') }}"></script>
<script src="{{ asset('js/simpleCart.min.js') }}"></script>

<link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700,900,900italic,700italic' rel='stylesheet' type='text/css'>

<script src="{{ asset('js/jquery.easing.min.js') }}"></script>
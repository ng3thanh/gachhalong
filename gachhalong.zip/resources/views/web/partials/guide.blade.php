<div class="coupons">
	<div class="container">
		<div class="coupons-grids text-center">
			<div class="col-md-4 coupons-gd">
				<span class="glyphicon glyphicon-check" aria-hidden="true"></span>
				<h4>LỰA CHỌN SẢN PHẨM</h4>
				<p>Lựa chọn các sản phẩm gạch uy tín.</p>
			</div>
			<div class="col-md-4 coupons-gd">
				<span class="glyphicon glyphicon-shopping-cart" aria-hidden="true"></span>
				<h4>GỌI ĐIỆN ĐẶT HÀNG</h4>
				<p>Gọi điện đặt hàng.</p>
			</div>
			<div class="col-md-4 coupons-gd">
				<span class="glyphicon glyphicon-random" aria-hidden="true"></span>
				<h4>GIAO HÀNG MIỄN PHÍ</h4>
				<p>Giao hàng tận nơi đến các cơ sở. Miễn phí trong bán kính 10 km</p>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
</div>
<!-- banner -->
<div class="banner-grid">
	<div id="visual">
		<div class="slide-visual">
			<!-- Slide Image Area (1000 x 424) -->
			<ul class="slide-group">
				@foreach($bigBanner as $value)
					<li><img class="img-responsive" src="{{ asset('images/'. $value->link) }}" alt="{{ $value->alt }}" /></li>
				@endforeach
			</ul>

			<!-- Slide Description Image Area (316 x 328) -->
			<div class="script-wrap">
				<ul class="script-group">
					@foreach($smallBanner as $value)
					<li>
						<div class="inner-script">
							<img class="img-responsive" src="{{ asset('images/'. $value->link) }}" alt="{{ $value->alt }}" />
						</div>
					</li>
					@endforeach
				</ul>
				<div class="slide-controller">
					<a href="#" class="btn-prev"><img src="{{ asset('images/btn_prev.png') }}" alt="Prev Slide" /></a> 
					<a href="#" class="btn-play"><img src="{{ asset('images/btn_play.png') }}" alt="Start Slide" /></a> 
					<a href="#" class="btn-pause"><img src="{{ asset('images/btn_pause.png') }}" alt="Pause Slide" /></a> 
					<a href="#" class="btn-next"><img src="{{ asset('images/btn_next.png') }}" alt="Next Slide" /></a>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="clearfix"></div>
	</div>
	<script type="text/javascript" src="{{ asset('js/pignose.layerslider.js') }}"></script>
	<script type="text/javascript">
    	//<![CDATA[
    		$(window).load(function() {
    			$('#visual').pignoseLayerSlider({
    				play    : '.btn-play',
    				pause   : '.btn-pause',
    				next    : '.btn-next',
    				prev    : '.btn-prev'
    			});
    		});
    	//]]>
	</script>
</div>
<!-- //banner -->